package Controlador;

import Vista.*;
import Modelo.*;
import java.util.ArrayList;
import java.util.Calendar;
import javax.swing.JOptionPane;

public class Main {

    private static VentanaPrincipal vpp;
    private static VentanaLogo vg;
    private static VentanaLogin vlg;
    private static VentanaCentro vc;
    private static VentanaPerfil vp;
    private static VentanaAlta va;
    private static VentanaCentroModificacion vcm;
    private static VentanaPartes vpa;
    private static VentanaSeleccionPartes vsp;
    private static VentanaSeleccionPerfiles vsper;
    private static VentanaBusquedaPartes vbp;
    
    private static Trabajador t;
    private static Trabajador tl;
    
    private static Parte p;
    private static Viaje v;
    private static Login l;
    private static Login l2;
    private static Centro c;
    private static Centro cl;
    
    private static ArrayList<String> nombres = new ArrayList();    
    private static ArrayList<Integer> centros = new ArrayList();
    private static ArrayList<Parte> partes = new ArrayList();
    private static ArrayList<Viaje> viajes = new ArrayList();
    
    private static String usuario;
    private static String tipo;
    private static String tipol;
    
    public static void main(String[] args) {      
        t = new Trabajador();
        l = new Login();
        l2 = new Login();
        tl = new Trabajador();
        cl = new Centro();
        GenericoBD.abrirConexion();
        mostrarLogo();
        mostrarLogin();
    }
    
/**Funciones para llenar los Combobox de las ventanas
 * 
 * @return
 * @throws Exception 
 */
  
    public static ArrayList<Integer> llenarCb() throws Exception{
        return CentroBD.buscarCentro();
    }
    
    public static ArrayList<String> llenarCbd(String centro) throws Exception{  
        return TrabajadorBD.buscarPorDni(centro);
    }
    
    public static ArrayList<String> llenarCbdLogistica(String centro) throws Exception{  
        return TrabajadorBD.buscarPorDniLogistica(centro);
    }
    
    public static ArrayList<Parte> llenarCbPartes() throws Exception{
        return partes;
    }
    
    public static ArrayList<Viaje> llenarViajes(String id) throws Exception{
        viajes = ViajeBD.busquedaViajeIDParte(id);
        return viajes;
    }
    
    public static String getDni(){
        return tl.getDni();
    }
    
    public static String getCentros() throws Exception{
        return cl.getId_centro();
    }
    
    /**Función que busca un usuario en la base de datos para saber si es un usuario de login
     * 
     * @param usuario
     * @param password
     * @return 
     */
    
    
    public static Login buscarUsuario(String usuario, String password){
        LoginBD.buscarUsuario(usuario, password);
        return l;
    }
    
    /**
     * insertar del login
     *
     */
    
    public static void insertarLogin(String usuario, String contrasena){    
        LoginBD.insertarLogin(usuario, contrasena); 
    }
    
    /**borrar del login
     * 
     * @param usuario
     * @param contrasena 
     */
    
    public static void borrarLogin(String usuario, String contrasena){  
        LoginBD.borrarLogin(usuario, contrasena);      
    }
    
    /**modificar del login
     * 
     * @param usuario
     * @param contrasena 
     */
    
    public static void modificarLogin(String usuario, String contrasena){       
        LoginBD.ModificarLogin(usuario, contrasena);   
    }
    
    /**Getter y setter viaje
     * 
     * @return 
     */

    public static Viaje getV() {
        return v;
    }

    public static void setV(Viaje v) {
        Main.v = v;
    }
       
    /**Getters para el login
     * 
     * @return 
     */
    
    public static Trabajador getTl() {
        return tl;
    }

    public static void setTl(Trabajador tl) {
        Main.tl = tl;
    }
    
    public static String getTipol() {
        return tipol;
    }

    public static void setTipol(String tipol) {
        Main.tipol = tipol;
    }
    
    public static Centro getC() {
        return c;
    }
    
    public static Login getL2() {
        return l2;
    }

    public static void setL2(Login l2) {
        Main.l2 = l2;
    }
    
    /**Funciones que obtienen el trabajador en función del DNI que tenga y distingue entre el que se ha logeado y el que se desea buscar
     * 
     * @param dni
     * @throws Exception 
     */
    
    
    public static void obtenerTrabajador(String dni) throws Exception{      
        t = TrabajadorBD.buscarDni(dni);  
    }
    
    public static void obtenerTrabajadorl(String dni) throws Exception{      
        tl = TrabajadorBD.buscarDni(dni);  
    }
    
    public static void setUsuario(String usuario) {
        Main.usuario = usuario;
    }
    
    public static void setTipo(String tipo) {
        Main.tipo = tipo;
    }
   
    public static String getCentro(Integer p){
        return nombres.get(p);
    }
    
    /**Funcion que busca el nombre del centro en función al ID
     * 
     * @param id
     * @return
     * @throws Exception 
     */
    
    public static String nombreCentroL(String id) throws Exception{
        cl = CentroBD.buscarID(id);
        return cl.getNombre();
    }
    
    public static String nombreCentro(String id) throws Exception{
        c = CentroBD.buscarID(id);
        return c.getNombre();
    }
    
    public static String nombreTrabajador(String dni) throws Exception{
        t = TrabajadorBD.buscarDni(dni);
        return t.getNombre();
    }
    
    public static String apellidoTrabajador(String dni) throws Exception{
        t = TrabajadorBD.buscarDni(dni);
        return t.getApellido1();
    }
    
    /**Funciones que muestran las diferentes ventanas
     * 
     */
    
    public static void mostrarPrincipal(){
        vg.setVisible(false);
        vpp = new VentanaPrincipal();
        vpp.setVisible(true);
    }
    
    public static void mostrarLogin(){
        vlg = new VentanaLogin(null, true);
        vlg.setVisible(true);
    }
    
    public static void mostrarLogo(){
        vg = new VentanaLogo();
        vg.setVisible(true);
    }
    
    public static void mostrarCentro(){
        vpp.setVisible(false);
        vc = new VentanaCentro();
        vc.setVisible(true);
    }
    
    public static void mostrarVentanaPerfil(){
        vpp.setVisible(false);
        vsper.setVisible(false);
        vp = new VentanaPerfil();
        vp.setVisible(true);
    }
    
    public static void mostrarVentanaAlta(){
        vpp.setVisible(false);
        vsper.setVisible(false);
        va = new VentanaAlta();
        va.setVisible(true);
    }
  
    public static void mostrarPartes(){
        vsp.setVisible(false);
        vpa = new VentanaPartes();
        vpa.setVisible(true);
    }
    
    public static void mostrarSeleccionPartes(){
        vpp.setVisible(false);
        vsp = new VentanaSeleccionPartes(null, true);
        vsp.setVisible(true);
    }
    
    public static void mostrarSeleccionPerfiles(){
        vpp.setVisible(false);
        vsper = new VentanaSeleccionPerfiles(null, true);
        vsper.setVisible(true);
    }

    public static void mostrarBusquedaPartes(){
        vsp.setVisible(false);
        vbp = new VentanaBusquedaPartes();
        vbp.setVisible(true);
    }
    
    /**Funciones para ir y volver entre las diferentes ventanas
     * 
     */
    
    public static void pasoVCMNuevo(){
        vc.setVisible(false);
        vcm = new VentanaCentroModificacion(false);
        vcm.setVisible(true);
    }
    
    public static void pasoVCM(){
        vc.setVisible(false);
        vcm = new VentanaCentroModificacion(true);
        vcm.setVisible(true);
    }
     
    public static void volverPrincipal(java.awt.Frame valor){
        valor.dispose();
        mostrarPrincipal();
    }
    
    public static void volverPrincipalD(java.awt.Dialog valor){
        valor.dispose();
        mostrarPrincipal();
    }
    
    public static void volverPartes(java.awt.Frame valor){
        valor.dispose();
        vsp.setVisible(true);
    }
    
    public static void volverCentro2(){
        vcm.dispose();
        mostrarCentro();
    }

    /**Funciones para buscar el DNI en la tabla Trabajador y los ID de la tabla Centros
     * 
     * @param dni
     * @return
     * @throws Exception 
     */
    
    public static boolean buscarDni(String dni) throws Exception{
        t = TrabajadorBD.buscarDni(dni);
        if (t == null)
            return false;
        return true;
    }
    
    public static boolean buscarId(String d) throws Exception{
        c = new Centro();
        c = CentroBD.buscarID(d);
        if (c == null)
            return false;
        return true;
    }
    
    /**Getters de la clase trabajador
     * 
     * @return 
     */
    
    public static String getNombre(){
        return t.getNombre();
    }
    
    public static String getApellido1(){
        return t.getApellido1();
    }
    
    public static String getApellido2(){
        return t.getApellido2();
    }
    
    public static String getCalle(){
        return t.getCalle();
    }
    
    public static String getNumero(){
        return t.getNumero();
    }
    
    public static String getPiso(){
        return t.getPiso();
    }
    
    public static String getMano(){
        return t.getMano();
    }
    
    public static String getTlf_empresa(){
        return t.getTlf_empresa();
    }
    
    public static String getTlf_personal(){
        return t.getTlf_personal();
    }
    
    public static Calendar getFecha_Nac(){
        Calendar cal = Calendar.getInstance();
        cal.setTime(t.getFecha_nac());
        return cal;
    }
    
    public static Float getSalario(){
        return t.getSalario();
    }

    public static boolean getTipo(){
         if (t instanceof Administracion)
            return true;
         else   
            return false;
    }
    
    /**Funciones de alta, baja y modificacion del trabajador
     * 
     * @param d
     * @param n
     * @param a1
     * @param a2
     * @param c
     * @param num
     * @param pi
     * @param ma
     * @param te
     * @param tp
     * @param s
     * @param fecha
     * @param tipo
     * @param centro
     * @param usu 
     */
    
    public static void altaTrabajador(String d, String n, String a1, String a2, String c, String num, String pi, String ma, String te, String tp, String s, Calendar fecha, String tipo, String centro, String usu){
        t = new Trabajador();
        t.setDni(d);
        t.setNombre(n);
        t.setApellido1(a1);
        t.setApellido2(a2);
        t.setCalle(c);
        t.setNumero(num);
        t.setPiso(pi);
        t.setMano(ma);
        t.setTlf_empresa(te);
        t.setTlf_personal(tp);
        t.setSalario(Float.parseFloat(s));
        t.setFecha_nac(fecha.getTime());
        
        TrabajadorBD.insertar(t, tipo, usu, centro);
    }
    
    public static void modificarTrabajador(String d, String n, String a1, String a2, String c, String num, String pi, String ma, String te, String tp, String s, Calendar fecha, String tipo){
        t.setDni(d);
        t.setNombre(n);
        t.setApellido1(a1);
        t.setApellido2(a2);
        t.setCalle(c);
        t.setNumero(num);
        t.setPiso(pi);
        t.setMano(ma);
        t.setTlf_empresa(te);
        t.setTlf_personal(tp);
        t.setSalario(Float.parseFloat(s));
        t.setFecha_nac(fecha.getTime());
        
        TrabajadorBD.actualizar(t, tipo);
    }
    
    public static void bajaTrabajador(){
        TrabajadorBD.borrarTrabajador(t);
    }

    /**Getters de la clase centros
     * 
     * @return 
     */
    
    public static String getCId(){
        return c.getId_centro();
    }
    
    public static String getCNombre(){
        return c.getNombre();
    }
    
    public static String getCTlf(){
        return c.getTlf_fijo();
    }
    
    public static String getCCp(){
        return c.getCp();
    }
    
    public static String getCProvincia(){
        return c.getProvincia();
    }
    
    public static String getCCiudad(){
        return c.getCiudad();
    }
    
    public static String getCCalle(){
        return c.getCalle();
    }
    
    public static String getCNumero(){
        return c.getNumero();
    }
    
    /**Funciones de alta, baja y modificacion de los centros
     * 
     * @param id
     * @param n
     * @param tlf
     * @param cp
     * @param p
     * @param ciu
     * @param ca
     * @param num 
     */
    
    public static void añadirCentro(String id, String n, String tlf, String cp, String p, String ciu, String ca, String num){
        c = new Centro();
        c.setId_centro(id);
        c.setNombre(n);
        c.setTlf_fijo(tlf);
        c.setCp(cp);
        c.setProvincia(p);
        c.setCiudad(ciu);
        c.setCalle(ca);
        c.setNumero(num);
        
        CentroBD.añadir(c);
    }
     
    public static void modificarCentro(String id, String n, String tlf, String cp, String p, String ciu, String ca, String num){
        c.setId_centro(id);
        c.setNombre(n);
        c.setTlf_fijo(tlf);
        c.setCp(cp);
        c.setProvincia(p);
        c.setCiudad(ciu);
        c.setCalle(ca);
        c.setNumero(num);
        
        CentroBD.modificar(c);
    }
    
    public static void borrarCentro(){
        centros.remove(c);
        CentroBD.borrar(c);
    }
    
    /**Getters de la clase parte
     * 
     * @return 
     */
    
    public static int getId_parte(){
        return p.getId_parte();
    }
    
    public static int getKmi(){
        return p.getKm_inicio();
    }
    
    public static int getKmf(){
        return p.getKm_fin();
    }
    
    public static int getGas(){
        return p.getGasoil();
    }
    
    public static int getAut(){
        return p.getAutopista();
    }
    
    public static int getDie(){
        return p.getDieta();
    }
    
    public static int getOtros(){
        return p.getOtros_gastos();
    }
    
    public static String getInc(){
        return p.getIncidencias();
    }
    
    public static String getVal(){
        return p.getValidado();
    }
    
    public static void setParte(Parte pa){
        p = pa;
    }
    
    /**Funciones para insertar, buscar, modificar y eliminar un parte
     * 
     * @param fi
     * @param ff
     * @param kmi
     * @param kmf
     * @param gas
     * @param aut
     * @param die
     * @param ot
     * @param in
     * @param d 
     */
    
    public static void insertarParte(Calendar fi, Calendar ff, int kmi, int kmf, int gas, int aut, int die, int ot, String in, String d){
        p = new Parte();
        p.setFecha_inicio(fi.getTime());
        p.setFecha_fin(ff.getTime());
        p.setKm_inicio(kmi);
        p.setKm_fin(kmf);
        p.setGasoil(gas);
        p.setAutopista(aut);
        p.setDieta(die);
        p.setOtros_gastos(ot);
        p.setIncidencias(in);
        p.setT(TrabajadorBD.buscarDni(d));
        
        ParteBD.insertarParte(p);
    }
    
    public static void insertarParteCerrado(Calendar fi, Calendar ff, int kmi, int kmf, int gas, int aut, int die, int ot, String in, String d){
        p = new Parte();
        p.setFecha_inicio(fi.getTime());
        p.setFecha_fin(ff.getTime());
        p.setKm_inicio(kmi);
        p.setKm_fin(kmf);
        p.setGasoil(gas);
        p.setAutopista(aut);
        p.setDieta(die);
        p.setOtros_gastos(ot);
        p.setIncidencias(in);
        p.setT(TrabajadorBD.buscarDni(d));
        
        ParteBD.insertarParteCerrado(p);
    }
    
    public static void buscarParteFecha(String dni, Calendar fi, Calendar ff, String tipo){ 
        partes = ParteBD.buscarParteFecha(dni, fi, ff, tipo);
    }
    
    
    public static Parte buscarParteID (String id){
        try
        {
            p = ParteBD.busquedaID(id);
        }
        
        catch(Exception e)
        {
            JOptionPane.showMessageDialog(null, "Se ha encontrado un error " + e.getMessage());
        }
        
        return p;
    }
    
    
    
    public static void obtenerParte(int id){
        for (int i = 0; i < partes.size(); i++) 
        {
            if (id == partes.get(i).getId_parte())
            {
                p = partes.get(i);
            }
        }
    }
       
    public static void modificarParte(int kmi, int kmf, int gas, int aut, int die, int ot, String in, String d){
        p.setKm_inicio(kmi);
        p.setKm_fin(kmf);
        p.setGasoil(gas);
        p.setAutopista(aut);
        p.setDieta(die);
        p.setOtros_gastos(ot);
        p.setIncidencias(in);
        p.setT(TrabajadorBD.buscarDni(d));
        
        ParteBD.modificarParte(p);
    }
    
    public static void cerrarParte(int kmi, int kmf, int gas, int aut, int die, int ot, String in, String d){
        p.setKm_inicio(kmi);
        p.setKm_fin(kmf);
        p.setGasoil(gas);
        p.setAutopista(aut);
        p.setDieta(die);
        p.setOtros_gastos(ot);
        p.setIncidencias(in);
        p.setT(TrabajadorBD.buscarDni(d));
        
        ParteBD.cerrarParte(p);
    }
    
    public static void validarParte(int kmi, int kmf, int gas, int aut, int die, int ot, String in, String d){
        p.setKm_inicio(kmi);
        p.setKm_fin(kmf);
        p.setGasoil(gas);
        p.setAutopista(aut);
        p.setDieta(die);
        p.setOtros_gastos(ot);
        p.setIncidencias(in);
        p.setT(TrabajadorBD.buscarDni(d));
        
        ParteBD.validarParte(p);
    }

    public static void borrarParte(){
        ParteBD.borrarParte(p);
    }
    
    /**Getters para la clase viaje
     * 
     * @return 
     */
  
    public static String getAlb(){
        return v.getAlbaran();
    }
    
    public static String getHorI(){
        return v.getHorainicio();
    }
    
    public static String getHorF(){
        return v.getHorafin();
    }
      
    public static String getVehi(){
        return v.getVehiculo();
    }
  
    /**Funciones para la clase viaje añadir y modificar
     * 
     * @param horainicio
     * @param horafin
     * @param vehiculo
     * @param id_parte 
     */
       
    public static void añadirViaje(String horainicio, String horafin, String vehiculo, String id_parte){ 
        v = new Viaje();
        
        v.setHorainicio(horainicio);
        v.setHorafin(horafin);
        v.setVehiculo(vehiculo);
        v.setP(ParteBD.busquedaID(id_parte));
        
        ViajeBD.insertarViaje(v);
    }
    
    public static void modificarViaje(String horainicio, String horafin, String vehiculo, String albaran){
        v = new Viaje();
        
        v.setHorainicio(horainicio);
        v.setHorafin(horafin);
        v.setVehiculo(vehiculo);
        
        ViajeBD.actualizarViaje(horainicio,horafin,vehiculo,albaran);    
    }

    /**Busqueda y borrado de viajes
     * 
     * @param albaran
     * @return 
     */
    
    public static Viaje buscarViajeID(String albaran){
        try
        {
            v = ViajeBD.busquedaViajeID(albaran);
        }    
        catch(Exception e)
        {
            JOptionPane.showMessageDialog(null, "Error" + e.getMessage());
        }
        return v;
    }
    
    public static void borrarViaje(String albaran){
        try
        {
            ViajeBD.borrarViaje(albaran);
        }
        
        catch(Exception e)
        {
            JOptionPane.showMessageDialog(null, "Error" + e.getMessage());
        }
    }
    
    /**Funcion para finalizar la ventana
     * 
     * @param valor 
     */
    
    public static void finalizarVentana(java.awt.Frame valor){
        valor.dispose();
        mostrarPrincipal();       
    }
}
