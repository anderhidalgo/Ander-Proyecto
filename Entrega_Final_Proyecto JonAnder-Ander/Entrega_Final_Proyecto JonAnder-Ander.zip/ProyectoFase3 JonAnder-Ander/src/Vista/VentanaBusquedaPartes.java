package Vista;

import Controlador.Main;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import Modelo.Parte;
import Modelo.Viaje;
import javax.swing.JComboBox;
import javax.swing.JTextField;

public class VentanaBusquedaPartes extends javax.swing.JFrame {

    private String estado;
    /** Abre la ventana y dependiendo del tipo de usuario que entre se mostrara de una forma u otra 
     * 
     */
    public VentanaBusquedaPartes() {
        initComponents();
        setLocationRelativeTo(null);
        if("L".equals(Main.getTipol())){   
            llenarCentroLogistica();
            llenarDniLogistica();
            mostrarBotones("L");
            estado = "Abierto";
        }
        else
        {
            mostrarBotones("A");
            llenarCentros();
            estado = "Cerrado"; 
        }
    }
/**
 * Funcion que llena el combo con los id de centro
 */
    private void llenarCentros()
    {
        try
        {
            ArrayList<Integer> listaCentros = Main.llenarCb();
            for(int x = 0; x < listaCentros.size();x++)
                comboCentros.insertItemAt(listaCentros.get(x).toString(), x);
        }
        catch (Exception e)
        {
            javax.swing.JOptionPane.showMessageDialog(this,e.getMessage());
        }
    }
    
   /** Funcion que llena el combo con los dni de trabajadores
    * 
    */ 
    private void llenarDNIs()
    {
        try
        {
            ArrayList<String> listaDNIs = Main.llenarCbdLogistica(comboCentros.getSelectedItem().toString());
            for(int x = 0; x < listaDNIs.size();x++)
                comboDni.insertItemAt(listaDNIs.get(x), x);
        }
        catch (Exception e)
        {
            javax.swing.JOptionPane.showMessageDialog(this,e.getMessage());
        }
    }
    
    /** Funcion que llena combobox de centros si eres un trabajador de logistica
     * 
     */
    private void llenarCentroLogistica()
    {
        try
        {  
            comboCentros.insertItemAt(Main.getCentros(), 0);
            comboCentros.setSelectedIndex(0);
            comboCentros.setEnabled(false);
        }
        catch (Exception e)
        {
            javax.swing.JOptionPane.showMessageDialog(this, e.getMessage());
        }
    }
    /** Funcion que llena el combobox de dni si eres un trabajador de logistica
     * 
     */
    private void llenarDniLogistica()
    {
        try
        {  
            comboDni.insertItemAt(Main.getDni(), 0);
            comboDni.setSelectedIndex(0);
            comboDni.setEnabled(false);
        }
        catch (Exception e)
        {
            javax.swing.JOptionPane.showMessageDialog(this, e.getMessage());
        }
    }
    /** Funcion que llena el combobox con los id de parte
     * 
     */
    private void llenarPartes()
    {
        try
        {
            ArrayList<Parte> listaPartes = Main.llenarCbPartes();
            for(int x = 0; x < listaPartes.size();x++)
                comboParte.insertItemAt(String.valueOf(listaPartes.get(x).getId_parte()), x);
        }
        catch (Exception e)
        {
            javax.swing.JOptionPane.showMessageDialog(this,e.getMessage());
        }
    }
    
    /** Funcion que llena los viajes en funcion al id del parte
     * 
     */
    private void llenarViajes()
    {
        borrarCampos();
        try
        {
            ArrayList<Viaje> listaViajes = Main.llenarViajes(comboParte.getSelectedItem().toString());
            for (int i = 0; i < listaViajes.size(); i++) {
                if (listaViajes.get(i) != null && i == 0)
                {
                    tfAlbaran1.setText(listaViajes.get(i).getAlbaran());
                    tfHoraInicio1.setText(listaViajes.get(i).getHorainicio());
                    tfHoraFin1.setText(listaViajes.get(i).getHorafin());
                    comboVehiculo1.setSelectedItem(listaViajes.get(i).getVehiculo());
                }
                else if (listaViajes.get(i)!= null && i == 1)
                {
                    tfAlbaran2.setText(listaViajes.get(i).getAlbaran());
                    tfHoraInicio2.setText(listaViajes.get(i).getHorainicio());
                    tfHoraFin2.setText(listaViajes.get(i).getHorafin());
                    comboVehiculo2.setSelectedItem(listaViajes.get(i).getVehiculo());
                }
                else if (listaViajes.get(i)!= null && i == 2)
                {
                    tfAlbaran3.setText(listaViajes.get(2).getAlbaran());
                    tfHoraInicio3.setText(listaViajes.get(i).getHorainicio());
                    tfHoraFin3.setText(listaViajes.get(i).getHorafin());
                    comboVehiculo3.setSelectedItem(listaViajes.get(i).getVehiculo());
                }
            }
        }
        catch (Exception e)
        {
            javax.swing.JOptionPane.showMessageDialog(this,"Error" + e.getMessage());
        }
    }
    
    /**Funcion para borrar los campos de viaje
     * 
     */
    public void borrarCampos()
    {
        tfAlbaran1.setText("");
        tfAlbaran2.setText("");
        tfAlbaran3.setText("");
        tfHoraInicio1.setText("");
        tfHoraInicio2.setText("");
        tfHoraInicio3.setText("");
        tfHoraFin1.setText("");
        tfHoraFin2.setText("");
        tfHoraFin3.setText("");
    }
    
    /** Funcion que muestra los datos de parte
     * 
     */
    public void mostrarDatos()
    {
        Main.obtenerParte(Integer.parseInt((String)comboParte.getSelectedItem()));
        tfKminicio.setText(String.valueOf(Main.getKmi()));
        tfKmfin.setText(String.valueOf(Main.getKmf()));
        tfGasoil.setText(String.valueOf(Main.getGas()));
        tfAutopistas.setText(String.valueOf(Main.getAut()));
        tfDietas.setText(String.valueOf(Main.getDie()));
        tfOtros.setText(String.valueOf(Main.getOtros()));
        taIncidencias.setText(Main.getInc());
    }
    /** Funcion que habilita o deshabilita los botones de aceptar y validar dependiendo si eres un usuario de administracion o logistica
     * 
     * @param tipo 
     */
    public void mostrarBotones(String tipo)
    {
        if (tipo.equalsIgnoreCase("L"))
        {    
            bAceptar.setVisible(true);
            bValidar.setVisible(false);
        }
        else
        {
            bAceptar.setVisible(false);
            bValidar.setVisible(true);            
        }
    }
    /** Funcion que muestra los viajes metiendolos en arraylist
     * 
     * @param id 
     */
    public void mostrarViajes(String id)
    {    
        try
        {
            Parte p = Controlador.Main.buscarParteID(id);
            ArrayList<Viaje> viajes = p.getViajes();
            
            ArrayList<JTextField> albarans = new ArrayList();
            ArrayList<JTextField> horais = new ArrayList();
            ArrayList<JTextField> horafs = new ArrayList();
            ArrayList<JComboBox> vehiculazos = new ArrayList();
            
            for(int x = 0; x < viajes.size(); x++)   
            {
                albarans.get(x).setText(viajes.get(x).getAlbaran());
                horais.get(x).setText(viajes.get(x).getHorainicio());
                horafs.get(x).setText(viajes.get(x).getHorafin());
                vehiculazos.get(x).setSelectedItem(viajes.get(x).getVehiculo());            
            }
            
        }
        catch (Exception e)
        {
            
          javax.swing.JOptionPane.showMessageDialog(this, "error" +e.getMessage());  
        }     
    }
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonGroup1 = new javax.swing.ButtonGroup();
        jLabel3 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        taIncidencias = new javax.swing.JTextArea();
        jPanel2 = new javax.swing.JPanel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        tfGasoil = new javax.swing.JTextField();
        tfAutopistas = new javax.swing.JTextField();
        tfDietas = new javax.swing.JTextField();
        tfOtros = new javax.swing.JTextField();
        jLabel12 = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        jLabel6 = new javax.swing.JLabel();
        tfKminicio = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        tfKmfin = new javax.swing.JTextField();
        bPartes = new javax.swing.JButton();
        bPrincipal = new javax.swing.JButton();
        jLabel4 = new javax.swing.JLabel();
        comboParte = new javax.swing.JComboBox<>();
        jPanel3 = new javax.swing.JPanel();
        jLabel5 = new javax.swing.JLabel();
        tfNombre = new javax.swing.JTextField();
        jLabel13 = new javax.swing.JLabel();
        tfApellido = new javax.swing.JTextField();
        bVisualizar = new javax.swing.JButton();
        dcFechaInicio = new datechooser.beans.DateChooserCombo();
        jLabel14 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        comboCentros = new javax.swing.JComboBox<>();
        dcFechaFin = new datechooser.beans.DateChooserCombo();
        comboDni = new javax.swing.JComboBox<>();
        jPanel4 = new javax.swing.JPanel();
        bModificar = new javax.swing.JRadioButton();
        bBorrar = new javax.swing.JRadioButton();
        bCerrar = new javax.swing.JRadioButton();
        bAceptar = new javax.swing.JButton();
        jPanel5 = new javax.swing.JPanel();
        jPanel6 = new javax.swing.JPanel();
        jLabel16 = new javax.swing.JLabel();
        tfAlbaran2 = new javax.swing.JTextField();
        jLabel17 = new javax.swing.JLabel();
        tfHoraInicio2 = new javax.swing.JTextField();
        jLabel18 = new javax.swing.JLabel();
        tfHoraFin2 = new javax.swing.JTextField();
        jLabel19 = new javax.swing.JLabel();
        comboVehiculo2 = new javax.swing.JComboBox<>();
        bAceptarViaje2 = new javax.swing.JButton();
        bBorrarViaje2 = new javax.swing.JButton();
        bEditarViaje2 = new javax.swing.JButton();
        jPanel7 = new javax.swing.JPanel();
        jLabel20 = new javax.swing.JLabel();
        tfAlbaran3 = new javax.swing.JTextField();
        jLabel21 = new javax.swing.JLabel();
        tfHoraInicio3 = new javax.swing.JTextField();
        jLabel22 = new javax.swing.JLabel();
        tfHoraFin3 = new javax.swing.JTextField();
        jLabel23 = new javax.swing.JLabel();
        comboVehiculo3 = new javax.swing.JComboBox<>();
        bAceptarViaje3 = new javax.swing.JButton();
        bBorrarViaje3 = new javax.swing.JButton();
        bEditarViaje3 = new javax.swing.JButton();
        jPanel8 = new javax.swing.JPanel();
        jLabel24 = new javax.swing.JLabel();
        tfAlbaran1 = new javax.swing.JTextField();
        jLabel25 = new javax.swing.JLabel();
        tfHoraInicio1 = new javax.swing.JTextField();
        jLabel26 = new javax.swing.JLabel();
        tfHoraFin1 = new javax.swing.JTextField();
        jLabel27 = new javax.swing.JLabel();
        comboVehiculo1 = new javax.swing.JComboBox<>();
        bAceptarViaje1 = new javax.swing.JButton();
        bBorrarViaje1 = new javax.swing.JButton();
        bEditarViaje1 = new javax.swing.JButton();
        bValidar = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel3.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        jLabel3.setText("VISUALIZAR PARTES");

        taIncidencias.setColumns(20);
        taIncidencias.setRows(5);
        jScrollPane1.setViewportView(taIncidencias);

        jPanel2.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Gastos", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Tahoma", 1, 11))); // NOI18N

        jLabel8.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel8.setText("Gasoil:");

        jLabel9.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel9.setText("Autopistas/Peajes:");

        jLabel10.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel10.setText("Dietas:");

        jLabel11.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel11.setText("Otros:");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel8)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(tfGasoil, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jLabel9)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(tfAutopistas, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jLabel10)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(tfDietas, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jLabel11)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(tfOtros, javax.swing.GroupLayout.DEFAULT_SIZE, 72, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel8)
                    .addComponent(jLabel9)
                    .addComponent(jLabel10)
                    .addComponent(jLabel11)
                    .addComponent(tfGasoil, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(tfAutopistas, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(tfDietas, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(tfOtros, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(24, Short.MAX_VALUE))
        );

        jLabel12.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel12.setText("Incidencias:");

        jPanel1.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Kilómetros realizados", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Tahoma", 1, 11))); // NOI18N

        jLabel6.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel6.setText("Kilómetros de inicio");

        jLabel7.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel7.setText("Kilómetros de fin");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGap(25, 25, 25)
                .addComponent(jLabel6)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(tfKminicio, javax.swing.GroupLayout.PREFERRED_SIZE, 105, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(59, 59, 59)
                .addComponent(jLabel7)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(tfKmfin, javax.swing.GroupLayout.DEFAULT_SIZE, 96, Short.MAX_VALUE)
                .addGap(26, 26, 26))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(22, 22, 22)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel6)
                    .addComponent(tfKminicio, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel7)
                    .addComponent(tfKmfin, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(20, Short.MAX_VALUE))
        );

        bPartes.setText("Volver a Partes");
        bPartes.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bPartesActionPerformed(evt);
            }
        });

        bPrincipal.setText("Volver a la Ventana Principal");
        bPrincipal.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bPrincipalActionPerformed(evt);
            }
        });

        jLabel4.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel4.setText("ID Parte");

        comboParte.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                comboParteItemStateChanged(evt);
            }
        });

        jPanel3.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));

        jLabel5.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel5.setText("Nombre");

        jLabel13.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel13.setText("Apellido");

        bVisualizar.setText("Visualizar partes");
        bVisualizar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bVisualizarActionPerformed(evt);
            }
        });

        jLabel14.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel14.setText("Fecha Inicio");

        jLabel1.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel1.setText("ID Centro");

        jLabel15.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel15.setText("Fecha Fin");

        jLabel2.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel2.setText("DNI");

        comboCentros.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                comboCentrosItemStateChanged(evt);
            }
        });

        comboDni.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                comboDniItemStateChanged(evt);
            }
        });

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(22, 22, 22)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(jLabel2)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addGap(416, 416, 416)
                                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(jLabel15)
                                    .addComponent(jLabel14))
                                .addGap(40, 40, 40)
                                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel3Layout.createSequentialGroup()
                                        .addComponent(dcFechaInicio, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                    .addGroup(jPanel3Layout.createSequentialGroup()
                                        .addComponent(dcFechaFin, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(0, 0, Short.MAX_VALUE))))
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addGap(18, 18, 18)
                                .addComponent(comboDni, 0, 205, Short.MAX_VALUE)
                                .addGap(782, 782, 782))))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel3Layout.createSequentialGroup()
                                .addComponent(jLabel13)
                                .addGap(18, 18, 18)
                                .addComponent(tfApellido))
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                .addComponent(tfNombre, javax.swing.GroupLayout.PREFERRED_SIZE, 154, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGroup(jPanel3Layout.createSequentialGroup()
                                    .addComponent(jLabel1)
                                    .addGap(18, 18, 18)
                                    .addComponent(comboCentros, javax.swing.GroupLayout.PREFERRED_SIZE, 168, javax.swing.GroupLayout.PREFERRED_SIZE))))
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(jLabel5)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(bVisualizar)
                        .addGap(36, 36, 36))))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(28, 28, 28)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel1)
                            .addComponent(comboCentros, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(23, 23, 23))
                    .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(jLabel14)
                        .addComponent(dcFechaInicio, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(comboDni, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel2))
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(25, 25, 25)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel5)
                            .addComponent(tfNombre, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(bVisualizar)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(dcFechaFin, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel15))
                .addGap(9, 9, 9)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel13)
                    .addComponent(tfApellido, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(28, Short.MAX_VALUE))
        );

        jPanel4.setBorder(javax.swing.BorderFactory.createTitledBorder("Opciones"));

        buttonGroup1.add(bModificar);
        bModificar.setText("Modificar");

        buttonGroup1.add(bBorrar);
        bBorrar.setText("Borrar");

        buttonGroup1.add(bCerrar);
        bCerrar.setText("Cerrar");

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGap(32, 32, 32)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(bCerrar)
                    .addComponent(bBorrar)
                    .addComponent(bModificar))
                .addContainerGap(60, Short.MAX_VALUE))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGap(27, 27, 27)
                .addComponent(bCerrar)
                .addGap(47, 47, 47)
                .addComponent(bModificar)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(bBorrar)
                .addGap(15, 15, 15))
        );

        bAceptar.setText("Aceptar");
        bAceptar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bAceptarActionPerformed(evt);
            }
        });

        jPanel5.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        jPanel6.setBorder(javax.swing.BorderFactory.createTitledBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)), "Viaje 2"));

        jLabel16.setText("Albarán:");

        tfAlbaran2.setEditable(false);

        jLabel17.setText("Hora inicio:");

        jLabel18.setText("Hora fin:");

        jLabel19.setText("Vehiculo:");

        comboVehiculo2.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Renault", "Opel", "Mercedes", "Fiat", "Volkswagen" }));

        bAceptarViaje2.setText("Aceptar");
        bAceptarViaje2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bAceptarViaje2ActionPerformed(evt);
            }
        });

        bBorrarViaje2.setText("Borrar");
        bBorrarViaje2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bBorrarViaje2ActionPerformed(evt);
            }
        });

        bEditarViaje2.setText("Editar");
        bEditarViaje2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bEditarViaje2ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
        jPanel6.setLayout(jPanel6Layout);
        jPanel6Layout.setHorizontalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel16)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(tfAlbaran2, javax.swing.GroupLayout.PREFERRED_SIZE, 53, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel17)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(tfHoraInicio2, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel18)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(tfHoraFin2, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel19)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(comboVehiculo2, javax.swing.GroupLayout.PREFERRED_SIZE, 93, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(bAceptarViaje2, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(bEditarViaje2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(bBorrarViaje2)
                .addGap(8, 8, 8))
        );
        jPanel6Layout.setVerticalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addGap(23, 23, 23)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel16)
                    .addComponent(tfAlbaran2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel17)
                    .addComponent(tfHoraInicio2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel18)
                    .addComponent(tfHoraFin2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel19)
                    .addComponent(comboVehiculo2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(bAceptarViaje2)
                    .addComponent(bBorrarViaje2)
                    .addComponent(bEditarViaje2))
                .addContainerGap(49, Short.MAX_VALUE))
        );

        jPanel7.setBorder(javax.swing.BorderFactory.createTitledBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)), "Viaje 3"));

        jLabel20.setText("Albarán:");

        tfAlbaran3.setEditable(false);

        jLabel21.setText("Hora inicio:");

        jLabel22.setText("Hora fin:");

        jLabel23.setText("Vehiculo:");

        comboVehiculo3.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Renault", "Opel", "Mercedes", "Fiat", "Volkswagen" }));

        bAceptarViaje3.setText("Aceptar");
        bAceptarViaje3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bAceptarViaje3ActionPerformed(evt);
            }
        });

        bBorrarViaje3.setText("Borrar");
        bBorrarViaje3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bBorrarViaje3ActionPerformed(evt);
            }
        });

        bEditarViaje3.setText("Editar");
        bEditarViaje3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bEditarViaje3ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel7Layout = new javax.swing.GroupLayout(jPanel7);
        jPanel7.setLayout(jPanel7Layout);
        jPanel7Layout.setHorizontalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel20)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(tfAlbaran3, javax.swing.GroupLayout.PREFERRED_SIZE, 53, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel21)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(tfHoraInicio3, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel22)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(tfHoraFin3, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel23)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(comboVehiculo3, javax.swing.GroupLayout.PREFERRED_SIZE, 93, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(bAceptarViaje3, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(bEditarViaje3)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(bBorrarViaje3)
                .addGap(8, 8, 8))
        );
        jPanel7Layout.setVerticalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addGap(23, 23, 23)
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel20)
                    .addComponent(tfAlbaran3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel21)
                    .addComponent(tfHoraInicio3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel22)
                    .addComponent(tfHoraFin3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel23)
                    .addComponent(comboVehiculo3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(bAceptarViaje3)
                    .addComponent(bBorrarViaje3)
                    .addComponent(bEditarViaje3))
                .addContainerGap(46, Short.MAX_VALUE))
        );

        jPanel8.setBorder(javax.swing.BorderFactory.createTitledBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)), "Viaje 1"));

        jLabel24.setText("Albarán:");

        tfAlbaran1.setEditable(false);

        jLabel25.setText("Hora inicio:");

        jLabel26.setText("Hora fin:");

        jLabel27.setText("Vehiculo:");

        comboVehiculo1.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Renault", "Opel", "Mercedes", "Fiat", "Volkswagen" }));

        bAceptarViaje1.setText("Aceptar");
        bAceptarViaje1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bAceptarViaje1ActionPerformed(evt);
            }
        });

        bBorrarViaje1.setText("Borrar");
        bBorrarViaje1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bBorrarViaje1ActionPerformed(evt);
            }
        });

        bEditarViaje1.setText("Editar");
        bEditarViaje1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bEditarViaje1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel8Layout = new javax.swing.GroupLayout(jPanel8);
        jPanel8.setLayout(jPanel8Layout);
        jPanel8Layout.setHorizontalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel8Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel24)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(tfAlbaran1, javax.swing.GroupLayout.PREFERRED_SIZE, 53, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel25)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(tfHoraInicio1, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel26)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(tfHoraFin1, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel27)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(comboVehiculo1, javax.swing.GroupLayout.PREFERRED_SIZE, 93, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(bAceptarViaje1, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(bEditarViaje1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(bBorrarViaje1)
                .addGap(8, 8, 8))
        );
        jPanel8Layout.setVerticalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel8Layout.createSequentialGroup()
                .addGap(23, 23, 23)
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel24)
                    .addComponent(tfAlbaran1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel25)
                    .addComponent(tfHoraInicio1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel26)
                    .addComponent(tfHoraFin1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel27)
                    .addComponent(comboVehiculo1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(bAceptarViaje1)
                    .addComponent(bBorrarViaje1)
                    .addComponent(bEditarViaje1))
                .addContainerGap(49, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jPanel8, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel7, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(0, 10, Short.MAX_VALUE))
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel5Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel8, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 9, Short.MAX_VALUE)
                .addComponent(jPanel6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jPanel7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(35, 35, 35))
        );

        bValidar.setText("Validar");
        bValidar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bValidarActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(49, 49, 49)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(39, 39, 39)
                                .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(jPanel2, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGroup(layout.createSequentialGroup()
                                            .addComponent(jLabel4)
                                            .addGap(18, 18, 18)
                                            .addComponent(comboParte, javax.swing.GroupLayout.PREFERRED_SIZE, 148, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                    .addComponent(jLabel12)
                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 646, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGroup(layout.createSequentialGroup()
                                            .addGap(225, 225, 225)
                                            .addComponent(bAceptar)
                                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                            .addComponent(bValidar)
                                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                            .addComponent(bPartes))))
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addGap(91, 91, 91)
                                        .addComponent(bPrincipal))
                                    .addGroup(layout.createSequentialGroup()
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(567, 567, 567)
                        .addComponent(jLabel3)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(25, 25, 25)
                .addComponent(jLabel3)
                .addGap(28, 28, 28)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(46, 46, 46)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel4)
                            .addComponent(comboParte, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(29, 29, 29)
                        .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(32, 32, 32)
                        .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jLabel12)
                        .addGap(18, 18, 18)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 109, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(27, 27, 27)
                        .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(39, 39, 39)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(bPartes)
                    .addComponent(bPrincipal)
                    .addComponent(bAceptar)
                    .addComponent(bValidar))
                .addContainerGap(24, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents
/** Boton que nos lleva a los partes
 * 
 * @param evt 
 */
    private void bPartesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bPartesActionPerformed
        Main.volverPartes(this);
    }//GEN-LAST:event_bPartesActionPerformed
/** Boton que nos lleva otra vez a la ventana principal
 * 
 * @param evt 
 */
    private void bPrincipalActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bPrincipalActionPerformed
        Main.volverPrincipal(this);
    }//GEN-LAST:event_bPrincipalActionPerformed

/**Funcion que cuando eliges un centro se rellena el combobox de los dnis que pertenecen a ese centro
 * 
 * @param evt 
 */    
    private void comboCentrosItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_comboCentrosItemStateChanged
        try
        {
            comboDni.removeAllItems();
            llenarDNIs();
        }
        catch(Exception e)
        {
            javax.swing.JOptionPane.showMessageDialog(this,e.getMessage());
        }
    }//GEN-LAST:event_comboCentrosItemStateChanged
/**Funcion que cuando eliges un dni se muestran el nombre y el apellido de ese trabajador
 * 
 * @param evt 
 */
    private void comboDniItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_comboDniItemStateChanged
        try
        {
           tfNombre.setText(Main.nombreTrabajador(comboDni.getSelectedItem().toString()));
           tfApellido.setText(Main.apellidoTrabajador(comboDni.getSelectedItem().toString()));
        }
        catch(Exception e)
        {
            javax.swing.JOptionPane.showMessageDialog(this,e.getMessage());
        }
    }//GEN-LAST:event_comboDniItemStateChanged
/** Boton que visualiza los partes del usuario segun la fecha
 * 
 * @param evt 
 */
    private void bVisualizarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bVisualizarActionPerformed
        try
        {
            comboParte.removeAllItems();
            Main.buscarParteFecha(comboDni.getSelectedItem().toString(), dcFechaInicio.getSelectedDate(), dcFechaFin.getSelectedDate(), estado);
            llenarPartes();
        }
        catch(Exception e)
        {
            JOptionPane.showMessageDialog(this, "Error " + e.getMessage());
        }
    }//GEN-LAST:event_bVisualizarActionPerformed
/** Funcion que cuando eliges un parte dependiendo si esta validado o no, te permite clickar en el boton de validar y luego te muestra los datos de ese parte y los viajes pertenecientes a ese parte
 * 
 * @param evt 
 */
    private void comboParteItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_comboParteItemStateChanged
        try {
            if("Si".equalsIgnoreCase(Main.llenarCbPartes().get(comboParte.getSelectedIndex()).getValidado()))
            {
                bValidar.setEnabled(false);
            }
            else
            {
                bValidar.setEnabled(true);
            }
            mostrarDatos();
            llenarViajes();
        } catch (Exception e) 
        {
            
        }
    }//GEN-LAST:event_comboParteItemStateChanged
/** Boton para que si el boton cerrar esta seleccionado cierra el parte, si el boton modificar esta seleccionado modifica el parte y si el boton borrar esta seleccionado borra el parte
 * 
 * @param evt 
 */
    private void bAceptarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bAceptarActionPerformed
        try
        {    
            if (bCerrar.isSelected())
            {
                Main.cerrarParte(Integer.parseInt(tfKminicio.getText()),Integer.parseInt(tfKmfin.getText()),Integer.parseInt(tfGasoil.getText()),Integer.parseInt(tfAutopistas.getText()),Integer.parseInt(tfDietas.getText()),Integer.parseInt(tfOtros.getText()),taIncidencias.getText(), comboDni.getSelectedItem().toString());
                JOptionPane.showMessageDialog(this, "El parte se ha cerrado con exito");
                Main.finalizarVentana(this);
            }
            else if (bModificar.isSelected()){
                Main.modificarParte(Integer.parseInt(tfKminicio.getText()),Integer.parseInt(tfKmfin.getText()),Integer.parseInt(tfGasoil.getText()),Integer.parseInt(tfAutopistas.getText()),Integer.parseInt(tfDietas.getText()),Integer.parseInt(tfOtros.getText()),taIncidencias.getText(), comboDni.getSelectedItem().toString());
                JOptionPane.showMessageDialog(this, "El parte se ha modificado con exito");
                Main.finalizarVentana(this);
            }
            else if (bBorrar.isSelected()){
                Main.borrarParte();
                JOptionPane.showMessageDialog(this, "El parte se ha borrado con exito");
                Main.finalizarVentana(this);
            }
            else
            {
                JOptionPane.showMessageDialog(this, "Tienes que elegir una de las opciones");
            }
        }
        catch (Exception e){
            JOptionPane.showMessageDialog(this, e.getMessage());
        }
    }//GEN-LAST:event_bAceptarActionPerformed
/** Boton que inserta el viaje
 * 
 * @param evt 
 */
    private void bAceptarViaje2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bAceptarViaje2ActionPerformed
        try
        {      
            Controlador.Main.añadirViaje(tfHoraInicio2.getText(), tfHoraFin2.getText(), comboVehiculo2.getSelectedItem().toString(), comboParte.getSelectedItem().toString());
            JOptionPane.showMessageDialog(this, "Se ha insertado el viaje");
        }
        catch (Exception e)
        {
            JOptionPane.showMessageDialog(this, "No se ha podido insertar o modificar el viaje " + e.getMessage());
        }
    }//GEN-LAST:event_bAceptarViaje2ActionPerformed
/** Boton que borra un viaje
 * 
 * @param evt 
 */
    private void bBorrarViaje2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bBorrarViaje2ActionPerformed
        Controlador.Main.borrarViaje(tfAlbaran2.getText());
        JOptionPane.showMessageDialog(this, "Se ha borrado el viaje 2"); 
    }//GEN-LAST:event_bBorrarViaje2ActionPerformed
/** Boton que inserta el viaje
 * 
 * @param evt 
 */
    private void bAceptarViaje3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bAceptarViaje3ActionPerformed
        try
        {      
            Controlador.Main.añadirViaje(tfHoraInicio3.getText(), tfHoraFin3.getText(), comboVehiculo3.getSelectedItem().toString(), comboParte.getSelectedItem().toString());
            JOptionPane.showMessageDialog(this, "Se ha insertado el viaje");           
        }
        catch (Exception e)
        {
            JOptionPane.showMessageDialog(this, "No se ha podido insertar o modificar el viaje " + e.getMessage());
        }
    }//GEN-LAST:event_bAceptarViaje3ActionPerformed
/** Boton que borra un viaje
 * 
 * @param evt 
 */
    private void bBorrarViaje3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bBorrarViaje3ActionPerformed
        Controlador.Main.borrarViaje(tfAlbaran3.getText());
        JOptionPane.showMessageDialog(this, "Se ha borrado el viaje 3"); 
    }//GEN-LAST:event_bBorrarViaje3ActionPerformed
/** Boton que inserta el viaje
 * 
 * @param evt 
 */
    private void bAceptarViaje1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bAceptarViaje1ActionPerformed
        try
        {                
            Controlador.Main.añadirViaje(tfHoraInicio1.getText(), tfHoraFin1.getText(), comboVehiculo1.getSelectedItem().toString(), comboParte.getSelectedItem().toString());
            JOptionPane.showMessageDialog(this, "Se ha insertado el viaje");            
        }
        catch (Exception e)
        {
            JOptionPane.showMessageDialog(this, "No se ha podido insertar o modificar el viaje " + e.getMessage());
        }
    }//GEN-LAST:event_bAceptarViaje1ActionPerformed
/** Boton que borra un viaje
 * 
 * @param evt 
 */
    private void bBorrarViaje1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bBorrarViaje1ActionPerformed
        Controlador.Main.borrarViaje(tfAlbaran1.getText());
        JOptionPane.showMessageDialog(this, "Se ha borrado el viaje 1");
    }//GEN-LAST:event_bBorrarViaje1ActionPerformed
/** Boton que valida el parte
 * 
 * @param evt 
 */
    private void bValidarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bValidarActionPerformed
        try
        { 
            Main.validarParte(Integer.parseInt(tfKminicio.getText()),Integer.parseInt(tfKmfin.getText()),Integer.parseInt(tfGasoil.getText()),Integer.parseInt(tfAutopistas.getText()),Integer.parseInt(tfDietas.getText()),Integer.parseInt(tfOtros.getText()),taIncidencias.getText(), comboDni.getSelectedItem().toString());
            JOptionPane.showMessageDialog(this, "El parte se ha validado con exito");
            Main.finalizarVentana(this);

        }
        catch (Exception e){
            JOptionPane.showMessageDialog(this, e.getMessage());
        }
    }//GEN-LAST:event_bValidarActionPerformed

 /** Boton que modifica el viaje
  * 
  * @param evt 
  */   
    private void bEditarViaje1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bEditarViaje1ActionPerformed
        try
        {
            Controlador.Main.modificarViaje(tfAlbaran1.getText(), tfHoraInicio1.getText(), tfHoraFin1.getText(), comboVehiculo1.getSelectedItem().toString());
            JOptionPane.showMessageDialog(this, "Se ha modificado el viaje ");
        }
        catch (Exception e)
        {
            JOptionPane.showMessageDialog(this, "No se ha podido modificar el viaje " + e.getMessage());
        }
    }//GEN-LAST:event_bEditarViaje1ActionPerformed
/** Boton que modifica el viaje
  * 
  * @param evt 
  */ 
    private void bEditarViaje2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bEditarViaje2ActionPerformed
        try 
        {
            Controlador.Main.modificarViaje(tfAlbaran2.getText(), tfHoraInicio2.getText(), tfHoraFin2.getText(), comboVehiculo2.getSelectedItem().toString());
            JOptionPane.showMessageDialog(this, "Se ha modificado el viaje ");
        }
        catch (Exception e)
        {
            JOptionPane.showMessageDialog(this, "No se ha podido modificar el viaje " + e.getMessage());
        }
    }//GEN-LAST:event_bEditarViaje2ActionPerformed
/** Boton que modifica el viaje
  * 
  * @param evt 
  */ 
    private void bEditarViaje3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bEditarViaje3ActionPerformed
        try    
        {
            Controlador.Main.modificarViaje(tfAlbaran3.getText(), tfHoraInicio3.getText(), tfHoraFin3.getText(), comboVehiculo3.getSelectedItem().toString());
            JOptionPane.showMessageDialog(this, "Se ha modificado el viaje ");
        }
        catch (Exception e)
        {
            JOptionPane.showMessageDialog(this, "No se ha podido modificar el viaje " + e.getMessage());
        }
    }//GEN-LAST:event_bEditarViaje3ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(VentanaBusquedaPartes.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(VentanaBusquedaPartes.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(VentanaBusquedaPartes.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(VentanaBusquedaPartes.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new VentanaBusquedaPartes().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton bAceptar;
    private javax.swing.JButton bAceptarViaje1;
    private javax.swing.JButton bAceptarViaje2;
    private javax.swing.JButton bAceptarViaje3;
    private javax.swing.JRadioButton bBorrar;
    private javax.swing.JButton bBorrarViaje1;
    private javax.swing.JButton bBorrarViaje2;
    private javax.swing.JButton bBorrarViaje3;
    private javax.swing.JRadioButton bCerrar;
    private javax.swing.JButton bEditarViaje1;
    private javax.swing.JButton bEditarViaje2;
    private javax.swing.JButton bEditarViaje3;
    private javax.swing.JRadioButton bModificar;
    private javax.swing.JButton bPartes;
    private javax.swing.JButton bPrincipal;
    private javax.swing.JButton bValidar;
    private javax.swing.JButton bVisualizar;
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.JComboBox<String> comboCentros;
    private javax.swing.JComboBox<String> comboDni;
    private javax.swing.JComboBox<String> comboParte;
    private javax.swing.JComboBox<String> comboVehiculo1;
    private javax.swing.JComboBox<String> comboVehiculo2;
    private javax.swing.JComboBox<String> comboVehiculo3;
    private datechooser.beans.DateChooserCombo dcFechaFin;
    private datechooser.beans.DateChooserCombo dcFechaInicio;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel24;
    private javax.swing.JLabel jLabel25;
    private javax.swing.JLabel jLabel26;
    private javax.swing.JLabel jLabel27;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JPanel jPanel8;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextArea taIncidencias;
    private javax.swing.JTextField tfAlbaran1;
    private javax.swing.JTextField tfAlbaran2;
    private javax.swing.JTextField tfAlbaran3;
    private javax.swing.JTextField tfApellido;
    private javax.swing.JTextField tfAutopistas;
    private javax.swing.JTextField tfDietas;
    private javax.swing.JTextField tfGasoil;
    private javax.swing.JTextField tfHoraFin1;
    private javax.swing.JTextField tfHoraFin2;
    private javax.swing.JTextField tfHoraFin3;
    private javax.swing.JTextField tfHoraInicio1;
    private javax.swing.JTextField tfHoraInicio2;
    private javax.swing.JTextField tfHoraInicio3;
    private javax.swing.JTextField tfKmfin;
    private javax.swing.JTextField tfKminicio;
    private javax.swing.JTextField tfNombre;
    private javax.swing.JTextField tfOtros;
    // End of variables declaration//GEN-END:variables
}
