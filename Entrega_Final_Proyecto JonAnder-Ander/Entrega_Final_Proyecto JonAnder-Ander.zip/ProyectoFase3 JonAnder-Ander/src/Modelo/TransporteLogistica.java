package Modelo;

public class TransporteLogistica extends Trabajador{
    
}
