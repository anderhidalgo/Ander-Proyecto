package Modelo;

import java.sql.*;

public class GenericoBD {
    private static Connection con;

    public static Connection getCon() {
        return con;
    }
    
     /**Funcion que abre la conexion con la base de datos en java
      * 
      * @return 
      */   
    public static boolean abrirConexion(){   
        try{
            
            Class.forName("oracle.jdbc.OracleDriver");
            String user = "daw10";
            String pass = "daw10";
            String url = "jdbc:oracle:thin:@SrvOracle:1521:orcl";
            
            con = DriverManager.getConnection (url, user, pass);
            
            return true;
            
        }
        catch(Exception e){
            return false;
        }
    }
    
    /**Funcion que cierra la conexion con la base de datos en java
     * 
     * @return 
     */
    public static boolean cerrarConexion(){
        try{
            con.close();            
            return true;
        }
        catch(Exception e){
            return false;
        }    
    }
}