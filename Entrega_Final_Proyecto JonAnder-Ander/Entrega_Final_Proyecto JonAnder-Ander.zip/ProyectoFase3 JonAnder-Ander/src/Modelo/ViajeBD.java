package Modelo;

import java.sql.*;
import java.util.ArrayList;
import static Modelo.GenericoBD.getCon;

public class ViajeBD {
    
    private static Viaje v;
    
    /** Funcion que busca el viaje segun su albaran
     * 
     * @param albaran
     * @return
     * @throws Exception 
     */
    
    public static Viaje busquedaViajeID(String albaran) throws Exception{
    
        GenericoBD.abrirConexion();
        
        String plantilla="SELECT * FROM Viaje WHERE albaran = ?";
        
        PreparedStatement ps = GenericoBD.getCon().prepareStatement(plantilla);
        ps.setString(1, albaran);
        ResultSet rs = ps.executeQuery();
        
        if (rs.next() == false)
        {
            v = null;
        }    
        else
        {
            v = new Viaje();
             
            v.setAlbaran(rs.getString("albaran"));
            v.setHorainicio(rs.getString("hora_inicio"));
            v.setHorafin(rs.getString("hora_fin"));
            v.setVehiculo(rs.getString("vehiculo"));    
        }
        
        GenericoBD.cerrarConexion();
        return v;
    }
    
    /**Funcion que busca el viaje segun el id del parte
     * 
     * @param id
     * @return
     * @throws Exception 
     */

    public static ArrayList<Viaje> busquedaViajeIDParte(String id) throws Exception{   
       
        ArrayList<Viaje> viajes = new ArrayList();

        GenericoBD.abrirConexion();

        String plantilla = "SELECT * FROM Viaje WHERE parte_id_parte = ?";

        PreparedStatement ps = getCon().prepareStatement(plantilla);
        ps.setString(1, id);
        ResultSet rs = ps.executeQuery();

        while(rs.next())
        {
            v = new Viaje();
            v.setAlbaran(rs.getString("albaran"));
            v.setHorainicio(rs.getString("hora_inicio"));
            v.setHorafin(rs.getString("hora_fin"));
            v.setVehiculo(rs.getString("vehiculo"));

            viajes.add(v);
        }
        GenericoBD.cerrarConexion();

        return viajes;
    }
    
    /** Funcion que inserta un viaje
     * 
     * @param v
     * @return 
     */
     
    
    public static boolean insertarViaje(Viaje v){      
        try
        {
            GenericoBD.abrirConexion();   
            
            PreparedStatement ps = GenericoBD.getCon().prepareStatement("INSERT INTO VIAJE(HORA_INICIO, HORA_FIN, VEHICULO, PARTE_ID_PARTE) values (?, ?, ?, ?)",new String[]{"ALBARAN"});

            ps.setString(1, v.getHorainicio());
            ps.setString(2, v.getHorafin());
            ps.setString(3, v.getVehiculo());
            ps.setInt(4, v.getP().getId_parte());

            ps.executeUpdate();
            return true;
        }       
        catch(Exception e)         
        {
            return false;
        }            
        finally
        {
            GenericoBD.cerrarConexion();
        }    
    }
        
    /** Funcion que actualiza un viaje
     * 
     * @param albaran
     * @param horainicio
     * @param horafin
     * @param vehiculo
     * @return 
     */
    
    public static boolean actualizarViaje(String albaran, String horainicio, String horafin, String vehiculo) {    
        try
        {        
            GenericoBD.abrirConexion();   
            String plantilla;

            plantilla = "UPDATE Viaje SET hora_inicio = ?, hora_fin = ?, vehiculo = ? WHERE albaran = ?";

            PreparedStatement ps = GenericoBD.getCon().prepareStatement(plantilla);
            
            ps.setString(1, horainicio);
            ps.setString(2, horafin);
            ps.setString(3, vehiculo);
            ps.setString(4, albaran);
                       
            ps.executeUpdate();
            return true;
            
        } 
        catch(Exception e)  
        {
            return false;
        }                    
        finally
        {
            GenericoBD.cerrarConexion();
        }    
    } 
    
    /** Funcion que borra un viaje
     * 
     * @param id
     * @return 
     */
           
    public static boolean borrarViaje(String id){   
        try
        {  
            GenericoBD.abrirConexion(); 
            
            String plantilla;

            plantilla = "DELETE FROM Viaje WHERE albaran = ?";

            PreparedStatement ps = GenericoBD.getCon().prepareStatement(plantilla);
            ps.setString(1, id);
             
            ps.executeUpdate();
            return true;     
        }
        catch(Exception e)     
        {
            return false;
        }             
        finally
        {
            GenericoBD.cerrarConexion();
        }     
    }    
}
