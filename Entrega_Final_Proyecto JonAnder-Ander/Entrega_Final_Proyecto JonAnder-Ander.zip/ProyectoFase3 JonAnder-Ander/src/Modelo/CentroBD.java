package Modelo;

import java.sql.*;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import oracle.jdbc.OracleTypes;

public class CentroBD extends GenericoBD {
    
    private static Centro c;
    
    
    /** Funcion que busca el centro
     * 
     * @return
     * @throws Exception 
     */
    
    public static ArrayList<Integer> buscarCentro() throws Exception
    {
        try
        {
            ArrayList<Integer> listaIds = new ArrayList();

            abrirConexion();
            
            CallableStatement cst = GenericoBD.getCon().prepareCall("{call FASE3.VER_CENTROS(?)}");
            
            cst.registerOutParameter(1, OracleTypes.CURSOR);
            cst.execute();
            ResultSet rs = (ResultSet) cst.getObject(1);
            while (rs.next()){
                   listaIds.add(rs.getInt(1)); 
            }
            cerrarConexion();
            return listaIds;
        }
        
        catch(Exception e)
        {
            return null;
        }
    }
    
    /** Funcion que busca el id de centro
     * 
     * @param Id_centro
     * @return
     * @throws Exception 
     */
    
    public static Centro buscarID(String Id_centro) throws Exception
    {      
        abrirConexion();

        String plantilla = "select * from centro where id_centro = ?";
        PreparedStatement sentenciaCon = GenericoBD.getCon().prepareStatement(plantilla);
        sentenciaCon.setString(1,Id_centro);
        ResultSet rs = sentenciaCon.executeQuery();
        
        if (rs.next())
        {
            c = new Centro();
            c.setId_centro(Id_centro);
            c.setNombre(rs.getString("nombre"));
            c.setTlf_fijo(rs.getString("tlf_fijo"));
            c.setCp(rs.getString("cp"));
            c.setProvincia(rs.getString("provincia"));
            c.setCiudad(rs.getString("ciudad"));
            c.setCalle(rs.getString("calle"));
            c.setNumero(rs.getString("numero"));
        }
        
        else
            c = null;
        
        cerrarConexion();
        return c;
    }
    
    /** Funcion que borra un centro
     * 
     * @param c
     * @return 
     */

    public static boolean borrar(Centro c){
        
    try
        {
            GenericoBD.abrirConexion();   
            
            String plantilla="delete from centro where id_centro = ? ";
            
            PreparedStatement ps = GenericoBD.getCon().prepareStatement(plantilla);
            ps.setString(1, c.getId_centro());
             
            ps.executeUpdate();
            
            return true;
        }
        catch(Exception e)
        {
            return false;
        }
        finally
        {
            GenericoBD.cerrarConexion();
        } 
    }
    
    /** Funcion que añade un centro
     * 
     * @param c
     * @return 
     */
    
    public static boolean añadir(Centro c){
        try
        {
            GenericoBD.abrirConexion();   

            String plantilla="insert into centro values (?, ?, ?, ?, ?, ?, ?, ?)";
            
            PreparedStatement ps = GenericoBD.getCon().prepareStatement(plantilla);
            ps.setString(1, c.getId_centro());
            ps.setString(2, c.getNombre());
            ps.setString(3, c.getTlf_fijo());
            ps.setString(4, c.getCp());
            ps.setString(5, c.getProvincia());
            ps.setString(6, c.getCiudad());
            ps.setString(7, c.getCalle());
            ps.setString(8, c.getNumero());
            
            ps.executeUpdate();

            return true;
        }
        catch(Exception e)
        {
            JOptionPane.showMessageDialog(null, " Error " + e.getMessage());
            return false;
        }
        finally
        {
            GenericoBD.cerrarConexion();
        }
    }
    
    /** Funcion que modifica un centro
     * 
     * @param c
     * @return 
     */
    
    public static boolean modificar(Centro c){
        try
        {
            GenericoBD.abrirConexion();   

            String plantilla="update Centro set  nombre = ?, tlf_fijo = ?, cp = ?, provincia = ?, ciudad = ?, calle = ?, numero = ? where id_centro= ? ";
            
            PreparedStatement ps = GenericoBD.getCon().prepareStatement(plantilla);

            ps.setString(1, c.getNombre());
            ps.setString(2, c.getTlf_fijo());
            ps.setString(3, c.getCp());
            ps.setString(4, c.getProvincia());
            ps.setString(5, c.getCiudad());
            ps.setString(6, c.getCalle());
            ps.setString(7, c.getNumero());
            ps.setString(8, c.getId_centro());

            ps.executeUpdate();
            
            return true;
        }
        catch(Exception e)
        {
            return false;
        }
        finally
        {
            GenericoBD.cerrarConexion();
        }
        
    }
}
