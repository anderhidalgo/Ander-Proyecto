package Modelo;

import java.sql.*;
import javax.swing.JOptionPane;
import static Modelo.GenericoBD.getCon;

public class LoginBD {
    
    private static Login l;
    
    /** Funcion que busca el usuario en la tabla Login
     * 
     * @param usu
     * @param pass
     * @return 
     */
    
    public static Login buscarUsuario (String usu, String pass){
        try
        {
            GenericoBD.abrirConexion();
            String plantilla= "SELECT * FROM Login WHERE usuario = ? AND contraseña = ? ";

            PreparedStatement ps = getCon().prepareStatement(plantilla);
            ps.setString(1, usu);
            ps.setString(2, pass);
            ResultSet resultado = ps.executeQuery();


            if (resultado.next() == false)  
            {
                l = null;
            }

            else
            {
                l = new Login();
                l.setUsuario(resultado.getString("usuario"));
                l.setContrasena(resultado.getString("contraseña"));

            }
        }
        catch(Exception e)   
        {
            JOptionPane.showMessageDialog(null, "Ha ocurrido un error " + e.getMessage());
            return null;
        }       
        finally  
        {
            GenericoBD.cerrarConexion();
            
        }
        return l;       
    }
    
    /** Funcion que inserta un usuario y contraseña en el Login 
     * 
     * @param usuario
     * @param contrasena
     * @return 
     */
    
    public static boolean insertarLogin (String usuario, String contrasena){
        try
        {
            GenericoBD.abrirConexion();   

            String plantilla="INSERT INTO Login VALUES (?, ?)";
            
            PreparedStatement ps = GenericoBD.getCon().prepareStatement(plantilla);
            
            ps.setString(1, usuario);
            ps.setString(2, contrasena);
            
            
            ps.executeUpdate();

            return true;  
        }
        catch(Exception e)
        {
            
            JOptionPane.showMessageDialog(null, "Error" +e.getMessage());
            return false;
        }
        finally           
        {  
            GenericoBD.cerrarConexion();
        }    
    } 
    
    /** Funcion que borra en el Login
     * 
     * @param usuario
     * @param contrasena
     * @return 
     */
     
         
    public static boolean borrarLogin (String usuario, String contrasena){
        try
        {
            GenericoBD.abrirConexion();   

            String plantilla="DELETE FROM Login WHERE usuario=?";
            
            PreparedStatement ps = GenericoBD.getCon().prepareStatement(plantilla);
            
            ps.setString(1, l.getUsuario());
            
            
            ps.executeUpdate();

            return true;  
        }
        catch(Exception e)
        {
            
            JOptionPane.showMessageDialog(null, "Error" +e.getMessage());
            return false;
        }
        finally  
        {   
            GenericoBD.cerrarConexion();
        }  
    }
    
    /** Funcion que modifica el Login y cambia la contraseña
     * 
     * @param usuario
     * @param contrasena
     * @return 
     */
  
  public static boolean ModificarLogin(String usuario, String contrasena){
        try
        {
            GenericoBD.abrirConexion();   

            String plantilla= " UPDATE Login SET contrasena= ?,  WHERE usuario=? ";
            
            PreparedStatement ps = GenericoBD.getCon().prepareStatement(plantilla);

            ps.setString(1, l.getContrasena());
            ps.setString(2, l.getUsuario());
            
            
            ps.executeUpdate();
            
            return true;
        }
        catch(Exception e)   
        {
            JOptionPane.showMessageDialog(null, "Error" +e.getMessage());
            return false;           
        }
        finally            
        {
            GenericoBD.cerrarConexion();
        }       
    }    
}
