package Modelo;

public class Administracion extends Trabajador{
    
}
