package Modelo;

import java.sql.*;
import javax.swing.JOptionPane;
import static Modelo.GenericoBD.getCon;
import java.util.ArrayList;

public class TrabajadorBD {
    
    private static Trabajador t;
    
    /** Funcion que busca el trabajador segun su dni
     * 
     * @param dni
     * @return 
     */
    public static Trabajador buscarDni(String dni){
        try
        {
            GenericoBD.abrirConexion();
            String plantilla="SELECT * FROM Trabajador WHERE dni = ?";

            PreparedStatement ps = GenericoBD.getCon().prepareStatement(plantilla);
            ps.setString(1, dni);
            ResultSet resultado = ps.executeQuery();                 
            
            if (resultado.next()== false)
            {
                t =  null;
            }
            else
            {
                    if (resultado.getString("tipo").compareToIgnoreCase("A")== 0)
                        t = new Administracion();
                    else
                        t = new TransporteLogistica();
                    
                    t.setDni(resultado.getString("dni"));
                    t.setNombre(resultado.getString("nombre"));
                    t.setApellido1(resultado.getString("apellido1"));
                    t.setApellido2(resultado.getString("apellido2"));
                    t.setCalle(resultado.getString("calle"));
                    t.setNumero(resultado.getString("numero"));
                    t.setPiso(resultado.getString("piso"));
                    t.setMano(resultado.getString("mano"));
                    t.setTlf_empresa(resultado.getString("tlf_empresa"));
                    t.setTlf_personal(resultado.getString("tlf_personal"));
                    t.setSalario(resultado.getFloat("salario"));
                    t.setFecha_nac(resultado.getDate("fecha_nac"));
                    Controlador.Main.getL2().setUsuario((resultado.getString("Login_usuario")));
                    Controlador.Main.setTipo(resultado.getString("tipo"));
            }
            return t;
        }
        catch(Exception e)
        {
            JOptionPane.showMessageDialog(null, "No se ha encontrado ningun trabajador con ese dni " + e.getMessage());
            return null;
        }
        finally
        {
            GenericoBD.cerrarConexion();
        }
    }
    
    /** Funcion que busca por usuario en trabajador
     * 
     * @param usu
     * @return 
     */
     
    public static Trabajador buscarPorUsuario(String usu){
        
            try
            {
        
            GenericoBD.abrirConexion();
            String plantilla="SELECT * FROM Trabajador WHERE Login_usuario = ?";

            PreparedStatement ps = getCon().prepareStatement(plantilla);
            ps.setString(1, usu);
            ResultSet resultado = ps.executeQuery();
            
            
            if (resultado.next() == false)
            {
                t = null;
            }
            else
            {
                if (resultado.getString("tipo").compareToIgnoreCase("A") == 0)
                {
                    t = new Administracion();
                }
                else
                {
                    t = new TransporteLogistica();
                }

                t.setDni(resultado.getString("dni"));
                t.setNombre(resultado.getString("nombre"));
                t.setApellido1(resultado.getString("apellido1"));
                t.setApellido2(resultado.getString("apellido2"));
                t.setCalle(resultado.getString("calle"));
                t.setNumero(resultado.getString("numero"));
                t.setPiso(resultado.getString("piso"));
                t.setMano(resultado.getString("mano"));
                t.setTlf_empresa(resultado.getString("tlf_empresa"));
                t.setTlf_personal(resultado.getString("tlf_personal"));
                t.setFecha_nac(resultado.getDate("fecha_nac"));
                t.setSalario(resultado.getFloat("salario"));
                
                Controlador.Main.setTipol(resultado.getString("tipo"));
                Controlador.Main.nombreCentroL(resultado.getString("Centro_id_centro"));
                Controlador.Main.setUsuario(resultado.getString("Login_usuario"));
                
                }
            
            return t;
            
            }
            
        catch(Exception e)
        {
            JOptionPane.showMessageDialog(null, "No se encuentra ningun trabajador " + e.getMessage());
            return null;
        }
            
        finally
        {
            GenericoBD.cerrarConexion();
        }
            
    }
    
    /** Funcion que busca por dni en trabajador
     * 
     * @param centro
     * @return
     * @throws Exception 
     */
    
     public static ArrayList<String> buscarPorDni(String centro) throws Exception{
        
        try
        {
            ArrayList<String> listaDNIs = new ArrayList();

            GenericoBD.abrirConexion();
            String plantilla="SELECT dni FROM Trabajador WHERE Centro_id_centro = ?";

            PreparedStatement ps = getCon().prepareStatement(plantilla);
            ps.setString(1, centro);
            ResultSet rs = ps.executeQuery();
            while (rs.next())
            {
                listaDNIs.add(rs.getString(1));
            }
            return listaDNIs;
        }
            
        catch(Exception e)
        {
            JOptionPane.showMessageDialog(null, " Error " + e.getMessage());
            return null;
        }   
    }
     
     /** Funcion que busca por dni siendo el tipo l que es de logistica
      * 
      * @param centro
      * @return
      * @throws Exception 
      */
     
    public static ArrayList<String> buscarPorDniLogistica(String centro) throws Exception{
        
        try
        {
            ArrayList<String> listaDNIs = new ArrayList();

            GenericoBD.abrirConexion();
            String plantilla="SELECT dni FROM Trabajador WHERE Centro_id_centro = ? AND tipo = 'L'";

            PreparedStatement ps = getCon().prepareStatement(plantilla);
            ps.setString(1, centro);
            ResultSet rs = ps.executeQuery();
            while (rs.next())
            {
                listaDNIs.add(rs.getString(1));
            }
            return listaDNIs;
        }
            
        catch(Exception e)
        {
            JOptionPane.showMessageDialog(null, " Error " + e.getMessage());
            return null;
        }   
    }
    
    /** Funcion que borra un trabajador
     * 
     * @param t
     * @return 
     */
    
    public static boolean borrarTrabajador(Trabajador t){
        
    try
        {
            GenericoBD.abrirConexion();   
            
            String plantilla="delete from trabajador where dni= ? ";
            
            PreparedStatement ps = GenericoBD.getCon().prepareStatement(plantilla);
            ps.setString(1, t.getDni());
             
            ps.executeUpdate();
            
            return true;
        }
        catch(Exception e)
        {
            return false;
        }
        finally
        {
            GenericoBD.cerrarConexion();
        }
        
    }
    
    /** Funcion que actualiza un trabajador
     * 
     * @param t
     * @param tipo
     * @return 
     */
    
    public static boolean actualizar(Trabajador t, String tipo){
        try
        {
            GenericoBD.abrirConexion();   

            String plantilla="update trabajador set nombre = ?,apellido1= ?,apellido2 = ?,calle = ?,numero = ?,piso = ?, mano = ?, tlf_empresa = ?, tlf_personal = ?,salario = ?,fecha_nac = ? where dni= ? ";
            
            PreparedStatement ps = GenericoBD.getCon().prepareStatement(plantilla);

            ps.setString(1, t.getNombre());
            ps.setString(2, t.getApellido1());
            ps.setString(3, t.getApellido2());
            ps.setString(4, t.getCalle());
            ps.setString(5, t.getNumero());
            ps.setString(6, t.getPiso());
            ps.setString(7, t.getMano());
            ps.setString(8, t.getTlf_empresa());
            ps.setString(9, t.getTlf_personal());
            ps.setFloat(10, t.getSalario());
            Date fecha = new Date(t.getFecha_nac().getTime());
            ps.setDate(11, fecha);
            ps.setString(12, t.getDni());

            ps.executeUpdate();
            
            return true;
        }
        catch(Exception e)
        {
            JOptionPane.showMessageDialog(null, e.getMessage());
            return false;
        }
        finally
        {
            GenericoBD.cerrarConexion();
        }
        
    }
    
    /** Funcion que inserta un trabajador
     * 
     * @param t
     * @param tipo
     * @param usuario
     * @param centro
     * @return 
     */
    
    public static boolean insertar(Trabajador t, String tipo, String usuario, String centro){
        try
        {
            GenericoBD.abrirConexion();   

            String plantilla="insert into Trabajador values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
            
            PreparedStatement ps = GenericoBD.getCon().prepareStatement(plantilla);
            
            ps.setString(1, t.getDni());
            ps.setString(2, t.getNombre());
            ps.setString(3, t.getApellido1());
            ps.setString(4, t.getApellido2());
            ps.setString(5, t.getCalle());
            ps.setString(6, t.getNumero());
            ps.setString(7, t.getPiso());
            ps.setString(8, t.getMano());
            ps.setString(9, t.getTlf_empresa());
            ps.setString(10, t.getTlf_personal());
            Date fecha = new Date(t.getFecha_nac().getTime());
            ps.setDate(11, fecha);
            ps.setFloat(12, t.getSalario());
            ps.setString(13, tipo);
            ps.setString(14, centro);
            ps.setString(15, usuario);

            ps.executeUpdate();

            return true;
        }
        catch(Exception e)
        {
            return false;
        }
        finally
        {
            GenericoBD.cerrarConexion();
        }
        
    }
}

