package Modelo;

public class Viaje {
    
    private String albaran;
    private String horainicio;
    private String horafin;
    private String vehiculo;
    private Parte p;
    
    public Viaje(String albaran, String horainicio, String horafin, String matricula) {
        
        this.albaran = albaran;
        this.horainicio = horainicio;
        this.horafin = horafin;
        this.vehiculo = matricula;
    }

    public Parte getP() {
        return p;
    }

    public void setP(Parte p) {
        this.p = p;
    }
    
    public Viaje() {
        
    }
     
    public String getAlbaran() {
        return albaran;
    }

    public void setAlbaran(String albaran) {
        this.albaran = albaran;
    }

    public String getHorainicio() {
        return horainicio;
    }

    public void setHorainicio(String horainicio) {
        this.horainicio = horainicio;
    }

    public String getHorafin() {
        return horafin;
    }

    public void setHorafin(String horafin) {
        this.horafin = horafin;
    }

    public String getVehiculo() {
        return vehiculo;
    }

    public void setVehiculo(String vehiculo) {
        this.vehiculo = vehiculo;
    }   
}
