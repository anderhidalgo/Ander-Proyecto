package Modelo;

import static Modelo.GenericoBD.getCon;
import java.sql.*;
import java.util.ArrayList;
import java.util.Calendar;
import javax.swing.JOptionPane;

public class ParteBD {
    
private static Parte p; 

/** Funcion que busca en el parte segun su id
 * 
 * @param id
 * @return 
 */
    public static Parte busquedaID(String id){   
        try
        {
            GenericoBD.abrirConexion();

            String plantilla= "SELECT * FROM Parte where id_parte = ?";

            PreparedStatement ps = getCon().prepareStatement(plantilla);
            ps.setString(1, id);
            ResultSet resultado = ps.executeQuery();

            p = new Parte();

            if (resultado.next() == false)
            {
                p = null;
            }
            else
            {
                p.setId_parte(resultado.getInt("id_parte"));
                p.setFecha_inicio(resultado.getDate("fecha_inicio"));
                p.setFecha_fin(resultado.getDate("fecha_fin"));
                p.setKm_inicio(resultado.getInt("km_inicio"));
                p.setKm_fin(resultado.getInt("km_fin"));
                p.setGasoil(resultado.getInt("gasoil"));
                p.setAutopista(resultado.getInt("autopista"));
                p.setDieta(resultado.getInt("dieta"));
                p.setOtros_gastos(resultado.getInt("otros"));
                p.setIncidencias(resultado.getString("incidencias"));
                p.setEstado(resultado.getString("estado"));
                p.setValidado(resultado.getString("validado"));   
            }
        } 
        catch(Exception e)
        {
            JOptionPane.showMessageDialog(null, "No se encuentra ningun parte" + e.getMessage());
            return null;
        }
        finally
        {
            GenericoBD.cerrarConexion();
        }
        return p;
    }

    /** Funcion que busca el parte segun dos fechas
     * 
     * @param dni
     * @param fch1
     * @param fch2
     * @param tipo
     * @return 
     */

    public static ArrayList<Parte> buscarParteFecha(String dni, Calendar fch1, Calendar fch2, String tipo)
    {

        ArrayList<Parte> Partes = new ArrayList();

        try
        {
            GenericoBD.abrirConexion();

            String plantilla="SELECT * FROM Parte WHERE trabajador_dni = ? AND fecha_inicio BETWEEN ? AND ? AND estado = ?";

            PreparedStatement ps = GenericoBD.getCon().prepareStatement(plantilla);

            ps.setString(1, dni);

            Date fecha = new Date(fch1.getTime().getTime());
            ps.setDate(2, fecha);

            Date fecha2 = new Date(fch2.getTime().getTime());
            ps.setDate(3, fecha2);

            ps.setString(4, tipo);

            ResultSet resultado = ps.executeQuery(); 

            while(resultado.next())
            { 
                p = new Parte();
                p.setId_parte(resultado.getInt("id_parte"));
                p.setFecha_inicio(resultado.getDate("fecha_inicio"));
                p.setFecha_fin(resultado.getDate("fecha_fin"));
                p.setKm_inicio(resultado.getInt("km_inicio"));
                p.setKm_fin(resultado.getInt("km_fin"));
                p.setGasoil(resultado.getInt("gasoil"));
                p.setAutopista(resultado.getInt("autopista"));
                p.setDieta(resultado.getInt("dieta"));
                p.setOtros_gastos(resultado.getInt("otros"));
                p.setIncidencias(resultado.getString("incidencias"));
                p.setEstado(resultado.getString("estado"));
                p.setValidado(resultado.getString("validado"));

                Partes.add(p);
            }

            return Partes;
        }
        catch(Exception e)
        {
            JOptionPane.showMessageDialog(null, "Error" + e.getMessage());
            return null;
        }
        finally
        {
            GenericoBD.cerrarConexion();
        }
    }

    /** Funcion que borra el parte segun el id
     * 
     * @param p
     * @return 
     */
    
    public static boolean borrarParte(Parte p){
        try
        {
            GenericoBD.abrirConexion();   

            String plantilla="DELETE FROM Parte WHERE id_parte= ? ";

            PreparedStatement ps = GenericoBD.getCon().prepareStatement(plantilla);
            ps.setInt(1, p.getId_parte());

            ps.executeUpdate();

            return true;
        }
        catch(Exception e)
        {
            JOptionPane.showMessageDialog(null, "Error" +e.getMessage());
            return false;
        }
        finally
        {
            GenericoBD.cerrarConexion();
        } 
    }

    /** Funcion que modifica el parte
     * 
     * @param p
     * @return 
     */
    
    public static boolean modificarParte(Parte p){
        try
        {
            GenericoBD.abrirConexion();   

            String plantilla= " UPDATE Parte SET km_inicio= ?,km_fin = ?,gasoil = ?,autopista = ?,dieta = ?, otros = ?, incidencias = ? WHERE id_parte= ? ";

            PreparedStatement ps = GenericoBD.getCon().prepareStatement(plantilla);

            ps.setInt(1, p.getKm_inicio());
            ps.setInt(2, p.getKm_fin());
            ps.setInt(3, p.getGasoil());
            ps.setInt(4, p.getAutopista());
            ps.setInt(5, p.getDieta());
            ps.setInt(6, p.getOtros_gastos());
            ps.setString(7, p.getIncidencias());
            ps.setInt(8, p.getId_parte());

            ps.executeUpdate();

            return true;
        }     
        catch(Exception e)   
        {
            JOptionPane.showMessageDialog(null, "Error" +e.getMessage());
            return false;           
        }
        finally
        {
            GenericoBD.cerrarConexion();
        }
    }
  
    /** Funcion que cierra el parte cambiando su estado a cerrado
     * 
     * @param p
     * @return 
     */
    
    public static boolean cerrarParte(Parte p){
        try
        {
            GenericoBD.abrirConexion();   

            String plantilla= " UPDATE Parte SET km_inicio= ?,km_fin = ?,gasoil = ?,autopista = ?,dieta = ?, otros = ?, incidencias = ?, estado = 'Cerrado' WHERE id_parte= ? ";
            
            PreparedStatement ps = GenericoBD.getCon().prepareStatement(plantilla);

            ps.setInt(1, p.getKm_inicio());
            ps.setInt(2, p.getKm_fin());
            ps.setInt(3, p.getGasoil());
            ps.setInt(4, p.getAutopista());
            ps.setInt(5, p.getDieta());
            ps.setInt(6, p.getOtros_gastos());
            ps.setString(7, p.getIncidencias());
            ps.setInt(8, p.getId_parte());
            
            ps.executeUpdate();
            
            return true;
        }
        catch(Exception e)     
        {
            JOptionPane.showMessageDialog(null, "Error" +e.getMessage());
            return false;           
        }
        finally   
        {
            GenericoBD.cerrarConexion();
        }
    }
    
    /** Funcion que inserta un parte
     * 
     * @param p
     * @return 
     */
  
    public static boolean insertarParte(Parte p){
        try
        {
            GenericoBD.abrirConexion();
            
            PreparedStatement ps = GenericoBD.getCon().prepareStatement("insert into parte(FECHA_INICIO, FECHA_FIN, KM_INICIO, KM_FIN, GASOIL, AUTOPISTA, DIETA, OTROS, INCIDENCIAS, TRABAJADOR_DNI, ESTADO, VALIDADO) values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'Abierto', 'No')",new String[]{"ID_PARTE"});

            Date fecha_inicio = new Date(p.getFecha_inicio().getTime());
            ps.setDate(1, fecha_inicio);
            Date fecha_fin = new Date(p.getFecha_fin().getTime());
            ps.setDate(2, fecha_fin);
            ps.setInt(3, p.getKm_inicio());
            ps.setInt(4, p.getKm_fin());
            ps.setInt(5, p.getGasoil());
            ps.setInt(6, p.getAutopista());
            ps.setInt(7, p.getDieta());
            ps.setInt(8, p.getOtros_gastos());
            ps.setString(9, p.getIncidencias());
            ps.setString(10, p.getT().getDni());

            ps.executeUpdate();

            return true;
        } 
        catch(Exception e)
        {   
            JOptionPane.showMessageDialog(null, "Error" +e.getMessage());
            return false;
        }
        finally    
        {      
            GenericoBD.cerrarConexion();
        }    
    }
    
    /** Funcion que inserta un parte ya cerrado
     * 
     * @param p
     * @return 
     */
    
    public static boolean insertarParteCerrado(Parte p){
        try
        {
            GenericoBD.abrirConexion();
            
            PreparedStatement ps = GenericoBD.getCon().prepareStatement("insert into parte(FECHA_INICIO, FECHA_FIN, KM_INICIO, KM_FIN, GASOIL, AUTOPISTA, DIETA, OTROS, INCIDENCIAS, TRABAJADOR_DNI, ESTADO) values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'Cerrado')",new String[]{"ID_PARTE"});

            Date fecha_inicio = new Date(p.getFecha_inicio().getTime());
            ps.setDate(1, fecha_inicio);
            Date fecha_fin = new Date(p.getFecha_fin().getTime());
            ps.setDate(2, fecha_fin);
            ps.setInt(3, p.getKm_inicio());
            ps.setInt(4, p.getKm_fin());
            ps.setInt(5, p.getGasoil());
            ps.setInt(6, p.getAutopista());
            ps.setInt(7, p.getDieta());
            ps.setInt(8, p.getOtros_gastos());
            ps.setString(9, p.getIncidencias());
            ps.setString(10, p.getT().getDni());

            ps.executeUpdate();

            return true;
        }
        catch(Exception e)
        {   
            JOptionPane.showMessageDialog(null, "Error" +e.getMessage());
            return false;
        }
        finally    
        {      
            GenericoBD.cerrarConexion();
        }    
    }
    
    /** Funcion que valida el parte
     * 
     * @param p
     * @return 
     */
    
    public static boolean validarParte(Parte p){
        try
        {
            GenericoBD.abrirConexion();   

            String plantilla= " UPDATE Parte SET km_inicio= ?,km_fin = ?,gasoil = ?,autopista = ?,dieta = ?, otros = ?, incidencias = ?, validado = 'Si' WHERE id_parte= ? ";
            
            PreparedStatement ps = GenericoBD.getCon().prepareStatement(plantilla);

            ps.setInt(1, p.getKm_inicio());
            ps.setInt(2, p.getKm_fin());
            ps.setInt(3, p.getGasoil());
            ps.setInt(4, p.getAutopista());
            ps.setInt(5, p.getDieta());
            ps.setInt(6, p.getOtros_gastos());
            ps.setString(7, p.getIncidencias());
            ps.setInt(8, p.getId_parte());
            
            ps.executeUpdate();
            
            return true;
        }
        catch(Exception e)    
        {
            JOptionPane.showMessageDialog(null, "Error" +e.getMessage());
            return false;           
        }
        finally     
        {
            GenericoBD.cerrarConexion();
        }
    }
}
  
 
 
 
    
    


    

