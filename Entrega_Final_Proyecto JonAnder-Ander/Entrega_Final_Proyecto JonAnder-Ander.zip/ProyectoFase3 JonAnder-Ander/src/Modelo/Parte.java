package Modelo;

import java.util.ArrayList;
import java.util.Date;

public class Parte {
    
    private Integer id_parte;
    private int km_inicio;
    private int km_fin;
    private int gasoil;
    private int autopista;
    private int dieta;
    private int otros_gastos;
    private String incidencias;
    private Date fecha_inicio;
    private Date fecha_fin;
    private String validado;
    private String estado;
    
    private Trabajador t;

    private ArrayList<Viaje> viajes;

    public ArrayList<Viaje> getViajes() throws Exception {
        viajes = ViajeBD.busquedaViajeIDParte(id_parte.toString());
        return viajes;
    }

    public void setViajes(ArrayList<Viaje> viajes) {
        this.viajes = viajes;
    }
    
    public Trabajador getT() {
        return t;
    }

    public void setT(Trabajador t) {
        this.t = t;
    }

    public Date getFecha_fin() {
        return fecha_fin;
    }

    public void setFecha_fin(Date fecha_fin) {
        this.fecha_fin = fecha_fin;
    }

    public Integer getId_parte() {
        return id_parte;
    }

    public void setId_parte(Integer id_parte) {
        this.id_parte = id_parte;
    }

    public Integer getKm_inicio() {
        return km_inicio;
    }

    public void setKm_inicio(Integer km_inicio) {
        this.km_inicio = km_inicio;
    }

    public Integer getKm_fin() {
        return km_fin;
    }

    public void setKm_fin(Integer km_fin) {
        this.km_fin = km_fin;
    }

    public Integer getGasoil() {
        return gasoil;
    }

    public void setGasoil(Integer gasoil) {
        this.gasoil = gasoil;
    }

    public Integer getAutopista() {
        return autopista;
    }

    public void setAutopista(Integer autopista) {
        this.autopista = autopista;
    }

    public Integer getDieta() {
        return dieta;
    }

    public void setDieta(Integer dieta) {
        this.dieta = dieta;
    }

    public Integer getOtros_gastos() {
        return otros_gastos;
    }

    public void setOtros_gastos(Integer otros_gastos) {
        this.otros_gastos = otros_gastos;
    }

    public String getIncidencias() {
        return incidencias;
    }

    public void setIncidencias(String incidencias) {
        this.incidencias = incidencias;
    }

    public Date getFecha_inicio() {
        return fecha_inicio;
    }

    public void setFecha_inicio(Date fecha_inicio) {
        this.fecha_inicio = fecha_inicio;
    }
    
    public String getValidado() {
        return validado;
    }

    public void setValidado(String validado) {
        this.validado = validado;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    public Parte(int id_parte, int km_inicio, int km_fin, int gasoil, int autopista, int dieta, int otros_gastos, String incidencias, Date fecha_inicio, Trabajador trabajador) {
        this.id_parte = id_parte;
        this.km_inicio = km_inicio;
        this.km_fin = km_fin;
        this.gasoil = gasoil;
        this.autopista = autopista;
        this.dieta = dieta;
        this.otros_gastos = otros_gastos;
        this.incidencias = incidencias;
        this.fecha_inicio = fecha_inicio;
        this.t = trabajador;
    }

    public Parte() {
        
    }  
}
